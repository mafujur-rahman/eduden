
import Home from './home/page'

export default function HomePage () {
  return (
    <section className='next__common'>
     <Home/>
    </section>
  )
}
