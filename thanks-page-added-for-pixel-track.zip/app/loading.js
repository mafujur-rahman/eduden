import Loader from "@/components/Loading/Loader";

export default function Loading() {
    // You can add any UI inside Loading, including a Skeleton.
    return <Loader />
  }