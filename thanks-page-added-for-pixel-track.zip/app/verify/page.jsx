export const metadata = {
  title: "eduden | verify",
  description:
    "Verify courses, certifications, and student credentials on Eduden – Kolkata’s trusted online learning platform offering authentic, expert-led education and career-focused training.",
};

export default function page() {
  return (
    <div>
      <div className="edn__hero__container">
        <h2 className="edn__title text-black">Coming Soon ....</h2>
      </div>
    </div>
  );
}
