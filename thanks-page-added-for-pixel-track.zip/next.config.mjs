/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['i.ibb.co', 'pub-1dbc090f54be4d24be3c4428336248d7.r2.dev', 'ik.imagekit.io', "via.placeholder.com"],
    },
};

export default nextConfig;
