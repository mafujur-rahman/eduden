import React from "react";

function CommonBtn({ text, className, icon }) {
  return (
    <button className="border border-[#fdd300] rounded-full py-1.5 px-6 flex items-center gap-x-1 hover:bg-[#fdd300] hover:text-black transition">
      {text}
      {icon && <span> {icon}</span>}
    </button>
  );
}

export default CommonBtn;
